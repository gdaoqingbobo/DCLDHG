# 读取drug_with_disease.txt
drug_disease = {}
with open('drug_with_disease.txt', 'r') as f:
    for line in f:
        drug, disease = map(int, line.strip().split())
        if disease not in drug_disease:
            drug_disease[disease] = []
        drug_disease[disease].append(drug)

# 读取microbe_with_disease.txt
microbe_disease = {}
with open('microbe_with_disease.txt', 'r') as f:
    for line in f:
        microbe, disease = map(int, line.strip().split())
        if disease not in microbe_disease:
            microbe_disease[disease] = []
        microbe_disease[disease].append(microbe)

# 存储所有的drug、microbe、disease和relation数据
drugs = []
microbes = []
diseases = []
relations = []

# 合并数据
for disease in set(drug_disease.keys()) & set(microbe_disease.keys()):
    for drug in drug_disease[disease]:
        for microbe in microbe_disease[disease]:
            drugs.append(str(drug))
            microbes.append(str(microbe))
            diseases.append(str(disease))
            relations.append('1')

# 将每列数据写入txt文件
with open('drug_microbe_disease_relation.txt', 'w') as f:
    # 写入每列数据，用制表符分隔
    for d, m, dis, r in zip(drugs, microbes, diseases, relations):
        f.write(f"{d}\t{m}\t{dis}\t{r}\n")

# 写入drug_with_disease_new.txt，只包含药物和疾病
with open('drug_with_disease_new.txt', 'w') as f:
    # 写入药物-疾病对，用空格分隔
    for d, dis in zip(drugs, diseases):
        f.write(f"{d}\t{dis}\n")

# 写入microbe_with_disease_new.txt，只包含微生物和疾病
with open('microbe_with_disease_new.txt', 'w') as f:
    # 写入微生物-疾病对，用空格分隔
    for m, dis in zip(microbes, diseases):
        f.write(f"{m}\t{dis}\n")

# 统计去重后的数量
unique_drugs = len(set(drugs))
unique_microbes = len(set(microbes))
unique_diseases = len(set(diseases))
total_relations = len(relations)

print(f"去重后的统计结果：")
print(f"药物数量: {unique_drugs}")
print(f"微生物数量: {unique_microbes}")
print(f"疾病数量: {unique_diseases}")
print(f"总关系数量: {total_relations}")
