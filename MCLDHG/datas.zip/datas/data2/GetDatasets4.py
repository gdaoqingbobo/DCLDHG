import pandas as pd
from collections import defaultdict

# find_tripartite_associations_optimized 函数 (与你之前提供的版本一致，确保输出 (drug, microbe, disease) 名称元组)
def find_tripartite_associations_optimized(
        file_m_dis, file_d_dis, file_m_d,
        col_m_mdis='microbe', col_dis_mdis='disease',
        col_d_ddis='drug', col_dis_ddis='disease',
        col_m_md='microbe', col_d_md='drug'
):
    print('\n' f"Loading microbe-disease data from: {file_m_dis}")
    df_m_dis = pd.read_excel(file_m_dis)
    m_dis_pairs = set(tuple(row) for row in df_m_dis[[col_m_mdis, col_dis_mdis]].values)
    print(f"Microbe-disease associations: {len(m_dis_pairs)}")

    print('\n' f"Loading drug-disease data from: {file_d_dis}")
    df_d_dis = pd.read_excel(file_d_dis)
    d_dis_pairs = set(tuple(row) for row in df_d_dis[[col_d_ddis, col_dis_ddis]].values)
    print(f"Drug-disease associations: {len(d_dis_pairs)}")

    print('\n' f"Loading microbe-drug data from {file_m_d}")
    df_m_d = pd.read_excel(file_m_d)
    m_d_pairs = set(tuple(row) for row in df_m_d[[col_m_md, col_d_md]].values)
    print(f"Microbe-drug associations: {len(m_d_pairs)}")

    microbes_by_disease = defaultdict(set)
    for m_id, dis_id in m_dis_pairs: # (microbe, disease)
        microbes_by_disease[dis_id].add(m_id)

    drugs_by_disease = defaultdict(set)
    for drug_id, dis_id in d_dis_pairs: # (drug, disease)
        drugs_by_disease[dis_id].add(drug_id)

    tripartite_associations = set()
    print("\nIdentifying tripartite associations (drug-microbe-disease)...")

    all_diseases_from_m_dis = {dis_id for _, dis_id in m_dis_pairs}
    all_diseases_from_d_dis = {dis_id for _, dis_id in d_dis_pairs}
    all_unique_diseases_in_pairs = all_diseases_from_m_dis.union(all_diseases_from_d_dis)
    print(f"Total unique diseases from input pairs to check: {len(all_unique_diseases_in_pairs)}")

    progress_counter = 0
    for current_dis_id in all_unique_diseases_in_pairs:
        progress_counter += 1
        if progress_counter % 1000 == 0 or progress_counter == len(all_unique_diseases_in_pairs):
            print(f"Processing disease {progress_counter}/{len(all_unique_diseases_in_pairs)}: {current_dis_id}")

        associated_microbes = microbes_by_disease.get(current_dis_id, set())
        associated_drugs = drugs_by_disease.get(current_dis_id, set())

        if associated_microbes and associated_drugs:
            for d_val in associated_drugs:
                for m_val in associated_microbes:
                    if (m_val, d_val) in m_d_pairs:
                        tripartite_associations.add((d_val, m_val, current_dis_id))

    print(f"\nFound {len(tripartite_associations)} tripartite associations (Drug-Microbe-Disease).")
    return tripartite_associations


if __name__ == '__main__':
    # 数据路径
    data_dir = "./13-data/"
    file_microbe_disease = f"{data_dir}MDsAs (DS18).xlsx"
    file_drug_disease = f"{data_dir}DgDsAs (DS19).xlsx"
    file_microbe_drug = f"{data_dir}MDgAs (DS20).xlsx"

    # 输出文件名
    output_excel_file = f"{data_dir}drug_microbe_disease_associations_relative_ids.xlsx" # 更新文件名
    output_txt_file = f"{data_dir}drug_microbe_disease_associations_relative_ids.txt"  # 更新TXT文件名

    # 执行推断
    inferred_triplets = find_tripartite_associations_optimized(
        file_m_dis=file_microbe_disease,
        file_d_dis=file_drug_disease,
        file_m_d=file_microbe_drug,
        col_m_mdis='microbe', col_dis_mdis='disease',
        col_d_ddis='drug', col_dis_ddis='disease',
        col_m_md='microbe', col_d_md='drug'
    )

    if inferred_triplets:
        print(f"\nTotal inferred tripartite associations (Drug-Microbe-Disease): {len(inferred_triplets)}")

        # --- 1. 提取并排序唯一实体 (名称) ---
        unique_drug_names = sorted(list({triplet[0] for triplet in inferred_triplets}))
        unique_microbe_names = sorted(list({triplet[1] for triplet in inferred_triplets}))
        unique_disease_names = sorted(list({triplet[2] for triplet in inferred_triplets}))

        num_unique_drugs = len(unique_drug_names)
        num_unique_microbes = len(unique_microbe_names)
        num_unique_diseases = len(unique_disease_names)

        print(f"Number of unique drugs in inferred associations: {num_unique_drugs}")
        print(f"Number of unique microbes in inferred associations: {num_unique_microbes}")
        print(f"Number of unique diseases in inferred associations: {num_unique_diseases}")

        # --- 2. 分配每个类别从0开始的相对ID，并创建映射 ---
        # 药物名称到其0-based相对ID的映射
        drug_name_to_relative_id = {name: i for i, name in enumerate(unique_drug_names)}
        relative_id_to_drug_name = {i: name for i, name in enumerate(unique_drug_names)}

        # 微生物名称到其0-based相对ID的映射
        microbe_name_to_relative_id = {name: i for i, name in enumerate(unique_microbe_names)}
        relative_id_to_microbe_name = {i: name for i, name in enumerate(unique_microbe_names)}

        # 疾病名称到其0-based相对ID的映射
        disease_name_to_relative_id = {name: i for i, name in enumerate(unique_disease_names)}
        relative_id_to_disease_name = {i: name for i, name in enumerate(unique_disease_names)}

        print("\nAssigned 0-based relative IDs for each entity type.")

        # --- 3. 准备数据框 ---
        sorted_named_triplets = sorted(list(inferred_triplets)) # (drug_name, microbe_name, disease_name)

        # 3.1 基于名称的三元关联 (保持不变)
        output_data_named = []
        for i, triplet in enumerate(sorted_named_triplets):
            output_data_named.append([i + 1, triplet[0], triplet[1], triplet[2]])
        df_output_named = pd.DataFrame(output_data_named,
                                       columns=['Association_ID', 'Drug_Name', 'Microbe_Name', 'Disease_Name'])
        print(f"\nPrepared {len(df_output_named)} name-based associations (Drug-Microbe-Disease).")
        if len(df_output_named) > 0: print(df_output_named.head(3))


        # 3.2 基于0-based相对ID的三元关联
        inferred_relative_id_triplets_list = []
        for d_name, m_name, dis_name in sorted_named_triplets:
            d_rel_id = drug_name_to_relative_id[d_name]
            m_rel_id = microbe_name_to_relative_id[m_name]
            dis_rel_id = disease_name_to_relative_id[dis_name]
            inferred_relative_id_triplets_list.append((d_rel_id, m_rel_id, dis_rel_id))

        output_data_relative_id_based = []
        for i, id_triplet in enumerate(inferred_relative_id_triplets_list):
            # id_triplet is (drug_relative_id, microbe_relative_id, disease_relative_id)
            output_data_relative_id_based.append([i + 1, id_triplet[0], id_triplet[1], id_triplet[2]])
        df_output_relative_id_based = pd.DataFrame(output_data_relative_id_based,
                                          columns=['Association_ID', 'Drug_Relative_ID', 'Microbe_Relative_ID', 'Disease_Relative_ID'])

        if not df_output_relative_id_based.empty:
            df_output_relative_id_based['Label'] = 1

        print(f"\nPrepared {len(df_output_relative_id_based)} 0-based relative ID associations with Labels (Drug-Microbe-Disease).")
        if len(df_output_relative_id_based) > 0: print(df_output_relative_id_based.head(3))


        # 3.3 ID映射数据框 (现在是 名称 <-> 0-based相对ID 的映射)
        df_drug_map_relative = pd.DataFrame(list(relative_id_to_drug_name.items()), columns=['Relative_ID', 'Drug_Name'])
        df_microbe_map_relative = pd.DataFrame(list(relative_id_to_microbe_name.items()), columns=['Relative_ID', 'Microbe_Name'])
        df_disease_map_relative = pd.DataFrame(list(relative_id_to_disease_name.items()), columns=['Relative_ID', 'Disease_Name'])
        print("\nPrepared Relative ID mapping DataFrames.")

        # --- 4. 保存到同一个Excel文件的不同Sheet ---
        print(f"\nSaving Excel results to '{output_excel_file}'...")
        try:
            with pd.ExcelWriter(output_excel_file, engine='openpyxl') as writer:
                df_output_named.to_excel(writer, sheet_name='Named_DMD_Associations', index=False)
                df_output_relative_id_based.to_excel(writer, sheet_name='Relative_ID_DMD_Assoc', index=False) # 更新sheet名
                df_drug_map_relative.to_excel(writer, sheet_name='Drug_Relative_ID_Map', index=False) # 更新sheet名
                df_microbe_map_relative.to_excel(writer, sheet_name='Microbe_Relative_ID_Map', index=False) # 更新sheet名
                df_disease_map_relative.to_excel(writer, sheet_name='Disease_Relative_ID_Map', index=False) # 更新sheet名
            print(f"Successfully saved Excel data to {output_excel_file}")
        except Exception as e:
            print(f"\nError saving to Excel: {e}")
            print("Please ensure you have 'openpyxl' or 'xlsxwriter' installed (e.g., pip install openpyxl).")

        # --- 5. 将 基于0-based相对ID的关联 的部分内容单独保存到 .txt 文件 ---
        if not df_output_relative_id_based.empty:
            print(f"\nSaving selected 0-based relative ID associations to TXT file: {output_txt_file}")
            try:
                # 选择需要的列: Drug_Relative_ID, Microbe_Relative_ID, Disease_Relative_ID, Label
                df_for_txt = df_output_relative_id_based[['Drug_Relative_ID', 'Microbe_Relative_ID', 'Disease_Relative_ID', 'Label']]

                df_for_txt.to_csv(output_txt_file, sep='\t', header=False, index=False)

                print(f"Successfully saved 0-based relative ID associations (Drug-Microbe-Disease) to {output_txt_file}")
                if len(df_for_txt) > 0:
                    print("  Example lines from TXT file:")
                    with open(output_txt_file, 'r') as f_txt:
                        for _ in range(min(3, len(df_for_txt))):
                            print(f"    {f_txt.readline().strip()}")
            except Exception as e:
                print(f"\nError saving to TXT file: {e}")
        else:
            print(f"\nSkipping TXT file generation as there are no 0-based relative ID associations.")
    else:
        print("\nNo tripartite associations were inferred based on the provided data.")